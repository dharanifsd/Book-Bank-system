# Book Bank System

A web-based book bank management system for educational institutions.

## Setup Instructions

1. **Install XAMPP or WAMP**
   - Download and install [XAMPP](https://www.apachefriends.org/download.html) or [WAMP](https://www.wampserver.com/en/) for your operating system.
   - Start Apache and MySQL services.

2. **Database Setup**
   - Open your web browser and navigate to `http://localhost/phpmyadmin`
   - Create a new database named `book_bank_system`
   - Alternatively, you can run the `test_connection.php` script which will create the database and tables automatically.

3. **Project Setup**
   - Copy the project folder to your web server's document root:
     - For XAMPP: `C:\xampp\htdocs\book_bank`
     - For WAMP: `C:\wamp\www\book_bank`
   - Access the application by navigating to `http://localhost/book_bank` in your web browser.

## Troubleshooting Database Connectivity

If you're experiencing database connectivity issues:

1. **Check MySQL Service**
   - Make sure MySQL service is running in XAMPP/WAMP control panel.

2. **Verify Database Credentials**
   - Check that the credentials in `backend/db.php` match your MySQL setup.
   - Default credentials are:
     - Host: localhost
     - Username: root
     - Password: (empty)
     - Database: book_bank_system

3. **Run Test Connection Script**
   - Navigate to `http://localhost/book_bank/backend/test_connection.php` to check database connectivity.
   - This script will also create the necessary database and tables if they don't exist.

4. **Check Error Logs**
   - Review PHP error logs in your XAMPP/WAMP installation directory.

## System Features

- Student and Staff Registration/Login
- Book Management
- Book Borrowing and Returns
- Search Functionality
- User Dashboard