<?php
// update_book.php

$servername = "localhost";
$username = "root";
$password = ""; // your DB password
$dbname = "book_bank_system"; // your DB name

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$action = $_POST['action'];
$book_id = $_POST['book_id'];

if ($action === 'update') {
  $book_title = $_POST['book_title'];
  $book_author = $_POST['book_author'];

  $sql = "UPDATE books SET title = ?, author = ? WHERE book_id = ?";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param("sss", $book_title, $book_author, $book_id);

  if ($stmt->execute()) {
    echo "<script>alert('Book updated successfully'); window.location.href='manage_books.html';</script>";
  } else {
    echo "Error: " . $stmt->error;
  }

} elseif ($action === 'delete') {
  $sql = "DELETE FROM book_data WHERE book_id = ?";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param("s", $book_id);

  if ($stmt->execute()) {
    echo "<script>alert('Book deleted successfully'); window.location.href='manage_books.html';</script>";
  } else {
    echo "Error: " . $stmt->error;
  }
}

$conn->close();
?>
