<!-- manage_books.html -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Manage Books | Book Bank</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">

  <!-- Container -->
  <div class="max-w-6xl mx-auto mt-12 bg-white rounded-xl shadow-lg p-8">
    <h2 class="text-3xl font-bold text-center text-indigo-700 mb-6">Manage Books</h2>
    <!-- Status / Error Message -->
    <div id="statusMessage" class="mt-4 p-3 rounded text-center text-sm font-semibold hidden"></div>


    <!-- Navigation -->
    <div class="flex justify-center mb-6 space-x-4">
      <a href="staff_dashboard.html" class="bg-gray-200 text-gray-800 py-2 px-4 rounded hover:bg-indigo-100">Dashboard</a>
      <a href="manage_books.php" class="bg-indigo-600 text-white py-2 px-4 rounded hover:bg-indigo-700">Manage Books</a>
      <a href="add_book.html" class="bg-gray-200 text-gray-800 py-2 px-4 rounded hover:bg-indigo-100">Add Book</a>
      <a href="manage_requests.html" class="bg-gray-200 text-gray-800 py-2 px-4 rounded hover:bg-indigo-100">Manage Requests</a>
      <a href="view_issued_books.html" class="bg-gray-200 text-gray-800 py-2 px-4 rounded hover:bg-indigo-100">Issued Books</a>
    </div>

    <!-- Add Book Button -->
    <div class="flex justify-end mb-4">
      <a href="add_book.html" class="bg-indigo-600 text-white py-2 px-4 rounded hover:bg-indigo-700">+ Add New Book</a>
    </div>

    <!-- Books Table -->
    <div class="overflow-x-auto">
      <table class="w-full text-sm text-left border border-gray-300 rounded">
        <thead class="bg-indigo-600 text-white">
          <tr>
            <th class="p-3 border">#</th>
            <th class="p-3 border">Book ID</th>
            <th class="p-3 border">Book Name</th>
            <th class="p-3 border">Department</th>
            <th class="p-3 border">Total Copies</th>
            <th class="p-3 border">Available Copies</th>
            <th class="p-3 border">Status</th>
            <th class="p-3 border">Actions</th>
          </tr>
        </thead>
        <tbody class="bg-white">

            <?php
            // Database connection
            $conn = new mysqli("localhost", "root", "", "book_bank_system");
            
            // Check connection
            if ($conn->connect_error) {
              echo "<tr><td colspan='8' class='p-3 border text-center text-red-600'>Database connection failed.</td></tr>";
              exit;
            }
            
            // Fetch all book records
            $sql = "SELECT * FROM book_data";
            $result = $conn->query($sql);
            
            if ($result && $result->num_rows > 0) {
              $serial = 1;
              while($row = $result->fetch_assoc()) {
                // Determine status color and label
                $statusLabel = ($row['book_status'] === 'Active') ? 'Active' : 'Inactive';
                $statusColor = ($row['book_status'] === 'Active') ? 'text-green-800 bg-green-100' : 'text-red-800 bg-red-100';
            
                echo "<tr class='hover:bg-gray-100'>";
                echo "<td class='p-3 border'>" . $serial++ . "</td>";
                echo "<td class='p-3 border'>" . htmlspecialchars($row['book_id']) . "</td>";
                echo "<td class='p-3 border'>" . htmlspecialchars($row['book_name']) . "</td>";
                echo "<td class='p-3 border'>" . htmlspecialchars($row['dept']) . "</td>";
                echo "<td class='p-3 border'>" . htmlspecialchars($row['tot_count']) . "</td>";
                echo "<td class='p-3 border'>" . htmlspecialchars($row['avl_count']) . "</td>";
                echo "<td class='p-3 border'><span class='px-2 py-1 text-xs font-semibold $statusColor rounded'>$statusLabel</span></td>";
                echo "<td class='p-3 border space-x-1'>
                        <a href='edit_book.html?book_id=" . urlencode($row['book_id']) . "' class='bg-yellow-400 text-white px-2 py-1 rounded hover:bg-yellow-500 text-xs'>Edit</a>
            
                        <form action='backend/delete_book.php' method='POST' class='inline' onsubmit=\"return confirm('Are you sure you want to delete this book?');\">
                          <input type='hidden' name='book_id' value='" . htmlspecialchars($row['book_id']) . "'>
                          <button type='submit' class='bg-red-500 text-white px-2 py-1 rounded hover:bg-red-600 text-xs'>Delete</button>
                        </form>
            
                        <form action='backend/toggle_status.php' method='POST' class='inline'>
                          <input type='hidden' name='book_id' value='" . htmlspecialchars($row['book_id']) . "'>
                          <button type='submit' class='bg-gray-500 text-white px-2 py-1 rounded hover:bg-gray-600 text-xs'>Toggle Status</button>
                        </form>
                      </td>";
                echo "</tr>";
              }
            } else {
              echo "<tr><td colspan='8' class='p-3 border text-center text-gray-500'>No books found</td></tr>";
            }
            
            $conn->close();
            ?>
            
            </tbody>
            
      </table>
    </div>

    <!-- Back link -->
    <a href="staff_dashboard.html" class="block text-center mt-6 text-indigo-600 hover:underline">← Back to Dashboard</a>
  </div>
  <script>
    // Show status/error messages from URL params
    window.onload = function() {
      const params = new URLSearchParams(window.location.search);
      const status = params.get('status');
      const error = params.get('error');
      const msgDiv = document.getElementById('statusMessage');
    
      if (status) {
        let message = '';
        if (status === 'deleted') {
          message = 'Book deleted successfully!';
        } else if (status === 'toggled') {
          message = 'Book status updated successfully!';
        }
    
        msgDiv.textContent = message;
        msgDiv.classList.remove('hidden');
        msgDiv.classList.add('bg-green-100', 'text-green-800');
      }
    
      if (error) {
        msgDiv.textContent = decodeURIComponent(error);
        msgDiv.classList.remove('hidden');
        msgDiv.classList.add('bg-red-100', 'text-red-800');
      }
    };
    </script>
    
</body>
</html>
