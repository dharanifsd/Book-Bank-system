<!-- view_books.php -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Available Books | Book Bank</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">

<div class="max-w-4xl mx-auto mt-10 bg-white rounded-xl shadow-lg p-8">
  <h2 class="text-2xl font-bold text-center mb-6 text-indigo-700">Available Books</h2>

  <table class="min-w-full table-auto border border-gray-300">
    <thead>
      <tr class="bg-indigo-600 text-white">
        <th class="p-2 border">Book ID</th>
        <th class="p-2 border">Book Title</th>
        <th class="p-2 border">Author</th>
        <th class="p-2 border">Department</th>
        <th class="p-2 border">Available Count</th>
      </tr>
    </thead>
    <tbody>

    <?php
    // Database connection (adjust details if needed)
    $conn = new mysqli("localhost", "root", "", "book_bank_system");

    // Check connection
    if ($conn->connect_error) {
      die("<tr><td colspan='5' class='p-2 border text-red-600 text-center'>Database connection failed.</td></tr>");
    }

    // Fetch required columns only
    $sql = "SELECT book_id, book_name, author, dept, avl_count FROM book_data WHERE book_status = 'Active'";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
      while($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td class='p-2 border'>" . htmlspecialchars($row["book_id"]) . "</td>";
        echo "<td class='p-2 border'>" . htmlspecialchars($row["book_name"]) . "</td>";
        echo "<td class='p-2 border'>" . htmlspecialchars($row["author"]) . "</td>";
        echo "<td class='p-2 border'>" . htmlspecialchars($row["dept"]) . "</td>";
        echo "<td class='p-2 border text-center'>" . htmlspecialchars($row["avl_count"]) . "</td>";
        echo "</tr>";
      }
    } else {
      echo "<tr><td colspan='5' class='p-2 border text-center text-gray-500'>No books found</td></tr>";
    }

    $conn->close();
    ?>

    </tbody>
  </table>

  <a href="../index.html" class="block text-center mt-6 text-indigo-600 hover:underline">← Back to home</a>

</div>

</body>
</html>
