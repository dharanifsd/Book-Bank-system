<?php
// Display errors for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

include 'db.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $student_name = $_POST['student_name'] ?? '';
    $reg_no = $_POST['reg_no'] ?? '';
    $email_id = $_POST['email_id'] ?? '';
    $password = $_POST['password'] ?? '';
    $dept = $_POST['dept'] ?? '';

    if (empty($student_name) || empty($reg_no) || empty($email_id) || empty($password) || empty($dept)) {
        header("Location: ../auth.html?error=" . urlencode("All fields are required"));
        exit();
    }

    // Check if email already exists
    $check_sql = "SELECT id FROM student_data WHERE email_id = ?";
    $check_stmt = $conn->prepare($check_sql);
    if (!$check_stmt) {
        header("Location: ../auth.html?error=" . urlencode("Database error: " . $conn->error));
        exit();
    }

    $check_stmt->bind_param("s", $email_id);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    
    if ($check_result->num_rows > 0) {
        header("Location: ../auth.html?error=" . urlencode("Email already registered"));
        exit();
    }
    $check_stmt->close();

    // Hash password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Insert new student
    $sql = "INSERT INTO student_data (student_name, reg_no, email_id, password, dept) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        header("Location: ../auth.html?error=" . urlencode("Database error: " . $conn->error));
        exit();
    }

    $stmt->bind_param("sisss", $student_name, $reg_no, $email_id, $hashed_password, $dept);

    if ($stmt->execute()) {
        header("Location: ../auth.html?status=success");
        exit();
    } else {
        header("Location: ../auth.html?error=" . urlencode("Registration failed: " . $stmt->error));
        exit();
    }

    $stmt->close();
} else {
    header("Location: ../auth.html?error=" . urlencode("Invalid request method"));
    exit();
}

$conn->close();
?>