<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Sanitize and fetch POST data
    $book_id = trim($_POST['book_id']);
    $book_name = trim($_POST['book_name']);
    $author = trim($_POST['author']);
    $dept = trim($_POST['dept']);
    $tot_count = intval($_POST['tot_count']);
    $avl_count = intval($_POST['avl_count']);
    $book_status = trim($_POST['book_status']);

    // Basic validation
    if (empty($book_id) || empty($book_name) || empty($author) || empty($dept) || $tot_count < 0 || $avl_count < 0 || empty($book_status)) {
        echo "Please fill in all required fields correctly.";
        exit;
    }

    // SQL query with prepared statement (added author)
    $sql = "INSERT INTO book_data (book_id, book_name, author, dept, tot_count, avl_count, book_status) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        echo "SQL Error: " . $conn->error;
        exit;
    }

    $stmt->bind_param("ssssiss", $book_id, $book_name, $author, $dept, $tot_count, $avl_count, $book_status);

    if ($stmt->execute()) {
        // Redirect back to book list page (make sure view_books.php exists)
        header("Location:view_books.php?message=Book+added+successfully");
        exit;
    } else {
        echo "Error adding book: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>
