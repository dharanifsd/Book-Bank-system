<?php
session_start();
require 'db.php';

$email = $_POST['email_id'];
$password = $_POST['password'];

// Check user in DB
$stmt = $conn->prepare("SELECT * FROM staff_data WHERE email_id = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
  $user = $result->fetch_assoc();

  if (password_verify($password, $user['password'])) {
    // Successful login
    $_SESSION['staff_id'] = $user['id'];
    $_SESSION['staff_name'] = $user['staff_name'];
    header("Location: ../staff_dashboard.html");
    exit();
  } else {
    // Incorrect password
    header("Location: ../auth.html?error=Incorrect%20password");
    exit();
  }
} else {
  // Email not found
  header("Location: ../auth.html?error=Staff%20not%20found");
  exit();
}
?>