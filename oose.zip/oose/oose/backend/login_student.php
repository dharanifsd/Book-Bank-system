<?php
session_start();
require 'db.php';

$email = $_POST['email_id'];
$password = $_POST['password'];

// Check user in DB
$stmt = $conn->prepare("SELECT * FROM student_data WHERE email_id = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
  $user = $result->fetch_assoc();

  if (password_verify($password, $user['password'])) {
    // Successful login
    $_SESSION['student_id'] = $user['id'];
    $_SESSION['student_name'] = $user['student_name'];
    header("Location: ../student_dashboard.html");
    exit();
  } else {
    // Incorrect password
    header("Location: ../auth.html?error=Incorrect%20password");
    exit();
  }
} else {
  // Email not found
  header("Location: ../auth.html?error=Student%20not%20found");
  exit();
}
?>
