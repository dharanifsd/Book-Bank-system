<?php
// backend/delete_book.php
include 'db.php'; // your DB connection

if (isset($_POST['book_id'])) {
    $book_id = $_POST['book_id'];

    $sql = "DELETE FROM book_data WHERE book_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $book_id);
    $stmt->execute();

    header("Location: ../manage_books.html?status=deleted");
    exit();
} else {
    header("Location: ../manage_books.html?error=Invalid Request");
    exit();
}
?>
