<?php
// backend/toggle_status.php
include 'db.php'; // your DB connection

if (isset($_POST['book_id'])) {
    $book_id = $_POST['book_id'];

    // First, get current status
    $sql = "SELECT book_status FROM book_data WHERE book_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $book_id);
    $stmt->execute();
    $stmt->bind_result($current_status);
    $stmt->fetch();
    $stmt->close();

    if ($current_status) {
        $new_status = ($current_status === 'Active') ? 'Inactive' : 'Active';

        $update_sql = "UPDATE book_data SET book_status = ? WHERE book_id = ?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("ss", $new_status, $book_id);
        $update_stmt->execute();
    }

    header("Location: ../manage_books.html?status=toggled");
    exit();
} else {
    header("Location: ../manage_books.html?error=Invalid Request");
    exit();
}
?>
