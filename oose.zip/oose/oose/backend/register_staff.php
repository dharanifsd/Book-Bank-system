<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $staff_name = $_POST['staff_name'];
    $reg_no = $_POST['reg_no'];
    $email_id = $_POST['email_id'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Secure password

    $sql = "INSERT INTO staff_data (staff_name, reg_no, email_id, password) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("siss", $staff_name, $reg_no, $email_id, $password);

    if ($stmt->execute()) {
        echo "success";
    } else {
        echo "error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>
