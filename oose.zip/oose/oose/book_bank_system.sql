-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 02, 2025 at 07:10 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `book_bank_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `book_data`
--
CREATE TABLE `book_data` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `book_id` VARCHAR(225) NOT NULL,
  `book_name` VARCHAR(225) NOT NULL,
  `dept` ENUM('CSE', 'ECE', 'EEE', 'MECH', 'CIVIL') NOT NULL,
  `tot_count` INT NOT NULL,
  `avl_count` INT NOT NULL,
  `book_status` ENUM('Active', 'Inactive') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `staff_data` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `staff_name` VARCHAR(225) NOT NULL,
  `reg_no` BIGINT NOT NULL,
  `email_id` VARCHAR(225) NOT NULL,
  `password` VARCHAR(255) NOT NULL,  -- Consider a longer password field
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `student_data` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `student_name` VARCHAR(225) NOT NULL,
  `reg_no` BIGINT NOT NULL,
  `email_id` VARCHAR(225) NOT NULL,
  `password` VARCHAR(255) NOT NULL,  -- Consider a longer password field
  `dept` ENUM('CSE', 'ECE', 'EEE', 'MECH', 'CIVIL') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `book_data`
--
ALTER TABLE `book_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `staff_data`
--
ALTER TABLE `staff_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_data`
--
ALTER TABLE `student_data`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `book_data`
--
ALTER TABLE `book_data`
  MODIFY `id` int(225) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `staff_data`
--
ALTER TABLE `staff_data`
  MODIFY `id` int(225) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_data`
--
ALTER TABLE `student_data`
  MODIFY `id` int(225) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
